#! /usr/bin/env python
while 1:
    input("Press Enter to save\n> ")
    open("save", 'a').close()
    print("Saved.")
